# YOLOV11改进方案(持续更新)

<a id="b"></a>

#### 目前支持的一些block (部分block可能会与主结构有冲突,具体以是否能运行为主)

##### C3k2系列
C3k2, C3k2_Faster, C3k2_ODConv, C3k2_Faster_EMA, C3k2_DBB, C3k2_CloAtt, C3k2_SCConv, C3k2_ScConv, C3k2_EMSC, C3k2_EMSCP, C3k2_KW, C3k2_DCNv2, C3k2_DCNv3, C3k2_OREPA, C3k2_REPVGGOREPA, C3k2_DCNv2_Dynamic, C3k2_MSBlock, C3k2_ContextGuided, C3k2_DLKA, C3k2_EMBC, C3k2_Parc, C3k2_DWR, C3k2_RFAConv, C3k2_RFCBAMConv, C3k2_RFCAConv, C3k2_MLCA, C3k2_AKConv, C3k2_UniRepLKNetBlock, C3k2_DRB, C3k2_DWR_DRB, C3k2_AggregatedAtt....(C3k2系列的改进都合适、太多了就不一一标注了)
##### C3系列  
C3, C3Ghost, C3_CloAtt, C3_SCConv, C3_ScConv, C3_EMSC, C3_EMSCP, C3_KW, C3_ODConv, C3_Faster, C3_Faster_EMA, C3_DCNv2, C3_DCNv3, C3_DBB, C3_OREPA, C3_REPVGGOREPA, C3_DCNv2_Dynamic, C3_MSBlock, C3_ContextGuided, C3_DLKA, C3_EMBC, C3_Parc, C3_DWR, C3_RFAConv, C3_RFCBAMConv, C3_RFCAConv, C3_MLCA, C3_AKConv, C3_UniRepLKNetBlock, C3_DRB, C3_DWR_DRB, C3_AggregatedAtt....(C3系列的改进都合适、太多了就不一一标注了)
##### 其他系列
VoVGSCSP, VoVGSCSPC, RCSOSA, CSP_EDLAN

<a id="c"></a>

#### 目前整合的一些注意力机制 还需要别的注意力机制可从[github](https://github.com/z1069614715/objectdetection_script/tree/master/cv-attention)拉取对应的代码到ultralytics/nn/extra_modules/attention.py即可. 视频教程可看项目视频中的(如何在yaml配置文件中添加注意力层)
EMA, SimAM, SpatialGroupEnhance, BiLevelRoutingAttention, BiLevelRoutingAttention_nchw, TripletAttention, CoordAtt, CBAM, BAMBlock, EfficientAttention(CloFormer中的注意力), LSKBlock, SEAttention, CPCA, deformable_LKA, EffectiveSEModule, LSKA, SegNext_Attention, DAttention(Vision Transformer with Deformable Attention CVPR2022), FocusedLinearAttention(ICCV2023), MLCA, TransNeXt_AggregatedAttention, LocalWindowAttention, ELA, CAA, CAFM, AFGCAttention(Neural Networks ECCV2024)

### YOLOV11
1. ultralytics/cfg/models/11/yolo11-efficientViT.yaml

    (CVPR2023)efficientViT替换yolo11主干.

2. ultralytics/cfg/models/11/yolo11-fasternet.yaml

    (CVPR2023)fasternet替换yolo11主干.

3. ultralytics/cfg/models/11/yolo11-timm.yaml

    使用timm支持的主干网络替换yolo11主干.timm的内容可看[这期视频](https://www.bilibili.com/video/BV1Mx4y1A7jy/)

4. ultralytics/cfg/models/11/yolo11-convnextv2.yaml

    使用convnextv2网络替换yolo11主干.

5. ultralytics/cfg/models/11/yolo11-dyhead.yaml

    添加基于注意力机制的目标检测头到yolo11中.

6. ultralytics/cfg/models/11/yolo11-bifpn.yaml

    添加BIFPN到yolo11中.  
    其中BIFPN中有三个可选参数：
    1. Fusion  
        其中BIFPN中的Fusion模块支持五种: weight, adaptive, concat, bifpn(default), SDI  
        其中weight, adaptive, concat出自[paper链接-Figure 3](https://openreview.net/pdf?id=q2ZaVU6bEsT), SDI出自[U-NetV2](https://github.com/yaoppeng/U-Net_v2)
    2. node_mode  
        其中支持这些[结构](#b)
    3. head_channel  
        BIFPN中的通道数,默认设置为256.
    项目视频百度云链接:关于BIFPN的说明

7. ultralytics/cfg/models/11/yolo11-C3k2-Faster.yaml

    使用C3k2-Faster替换C3k2.(使用FasterNet中的FasterBlock替换C3k2中的Bottleneck)
    项目视频百度云链接:20240729版本更新说明

8. ultralytics/cfg/models/11/yolo11-C3k2-ODConv.yaml

    使用C3k2-ODConv替换C3k2.(使用ODConv替换C3k2中的Bottleneck中的Conv)
    项目视频百度云链接:20240729版本更新说明

9. ultralytics/cfg/models/11/yolo11-EfficientFormerV2.yaml

    使用EfficientFormerV2网络替换yolo11主干.(需要看[常见错误和解决方案的第五点](#a))  
10. ultralytics/cfg/models/11/yolo11-C3k2-Faster-EMA.yaml

    使用C3k2-Faster-EMA替换C3k2.(C3k2-Faster-EMA推荐可以放在主干上,Neck和head部分可以选择C3k2-Faster)
    项目视频百度云链接:20240729版本更新说明

11. ultralytics/cfg/models/11/yolo11-C3k2-DBB.yaml

    使用C3k2-DBB替换C3k2.(使用DiverseBranchBlock替换C3k2中的Bottleneck中的Conv)
    项目视频百度云链接:20240729版本更新说明

12. 增加Adaptive Training Sample Selection匹配策略.

    在ultralytics/utils/loss.py中的class 11DetectionLoss中自行选择对应的self.assigner即可.  
    此ATSS匹配策略目前占用显存比较大,因此使用的时候需要设置更小的batch,后续会进行优化这一功能.

13. ultralytics/cfg/models/11/yolo11-slimneck.yaml

    使用[VoVGSCSP\VoVGSCSPC和GSConv](https://github.com/AlanLi1997/slim-neck-by-gsconv)替换yolo11 neck中的C3k2和Conv.

14. ultralytics/cfg/models/11/yolo11-attention.yaml

    可以看项目视频-如何在yaml配置文件中添加注意力层  
    多种注意力机制在yolo11中的使用. [多种注意力机制github地址](https://github.com/z1069614715/objectdetection_script/tree/master/cv-attention)  
    目前内部整合的注意力可看[链接](#c)

15. Asymptotic Feature Pyramid Network[reference](https://github.com/gyyang23/AFPN/tree/master)

    a. ultralytics/cfg/models/11/yolo11-AFPN-P345.yaml  
    b. ultralytics/cfg/models/11/yolo11-AFPN-P345-Custom.yaml  
    c. ultralytics/cfg/models/11/yolo11-AFPN-P2345.yaml  
    d. ultralytics/cfg/models/11/yolo11-AFPN-P2345-Custom.yaml  
    其中Custom中的block支持这些[结构](#b) [B站介绍说明](https://www.bilibili.com/video/BV1bh411A7yj/)

16. ultralytics/cfg/models/11/yolo11-vanillanet.yaml

    vanillanet替换yolo11主干.

17. ultralytics/cfg/models/11/yolo11-C3k2-CloAtt.yaml

    使用C3k2-CloAtt替换C3k2.(使用CloFormer中的具有全局和局部特征的注意力机制添加到C3k2中的Bottleneck中)(需要看[常见错误和解决方案的第五点](#a))  
    项目视频百度云链接:20240729版本更新说明

18. ultralytics/cfg/models/11/yolo11-RevCol.yaml

    使用[(ICLR2023)Reversible Column Networks](https://github.com/megvii-research/RevCol)对yolo11主干进行重设计.
    视频:https://www.bilibili.com/video/BV1Mh4y1y76u/

19. ultralytics/cfg/models/11/yolo11-LSKNet.yaml

    LSKNet(2023旋转目标检测SOTA的主干)替换yolo11主干.

20. ultralytics/cfg/models/11/yolo11-C3k2-SCConv.yaml

    SCConv(CVPR2020 http://mftp.mmcheng.net/Papers/20cvprSCNet.pdf)与C3k2融合.
    项目视频百度云链接:SCConv和ScConv的使用教程
    针对v11的架构，C3k2-SCConv在n大小下只适用于替换通道数为1024的c3k2，如果不是n大小可以尝试替换更多，不报错就证明没问题。

21. ultralytics/cfg/models/11/yolo11-C3k2-SCcConv.yaml

    ScConv(CVPR2023 https://openaccess.thecvf.com/content/CVPR2023/papers/Li_SCConv_Spatial_and_Channel_Reconstruction_Convolution_for_Feature_Redundancy_CVPR_2023_paper.pdf)与C3k2融合.  
    (取名为SCcConv的原因是在windows下命名是不区分大小写的)
    项目视频百度云链接:SCConv和ScConv的使用教程
    针对v11的架构，C3k2-SCcConv在n大小下只适用于替换通道数为1024的c3k2，如果不是n大小可以尝试替换更多，不报错就证明没问题。

22. MPDiou.[论文链接](https://arxiv.org/pdf/2307.07662v1.pdf)

    请看LOSS改进系列.md

23. ultralytics/cfg/models/11/yolo11-LAWDS.yaml

    Light Adaptive-weight downsampling.自研模块,具体讲解请看百度云链接中的视频.
    项目视频百度云链接:LAWDS讲解

24. ultralytics/cfg/models/11/yolo11-C3k2-EMSC.yaml

    Efficient Multi-Scale Conv.自研模块,具体讲解请看百度云链接中的视频.
    项目视频百度云链接:EMSC,EMSCP讲解

25. ultralytics/cfg/models/11/yolo11-C3k2-EMSCP.yaml

    Efficient Multi-Scale Conv Plus.自研模块,具体讲解请看百度云链接中的视频.
    项目视频百度云链接:EMSC,EMSCP讲解

26. ultralytics/cfg/models/11/yolo11-RCSOSA.yaml

    使用[RCS-YOLO](https://github.com/mkang315/RCS-YOLO/tree/main)中的RCSOSA替换C3k2.
    项目视频百度云链接:20240908版本更新说明

27. ultralytics/cfg/models/11/yolo11-KernelWarehouse.yaml
    
    使用[Towards Parameter-Efficient Dynamic Convolution](https://github.com/OSVAI/KernelWarehouse)添加到yolo11中.  
    使用此模块需要注意,在epoch0-20的时候精度会非常低,过了20epoch会正常.
    项目视频百度云链接:20240803版本更新说明

28. Normalized Gaussian Wasserstein Distance.[论文链接](https://arxiv.org/abs/2110.13389)

    在Loss中使用:
        在ultralytics/utils/loss.py中的BboxLoss class中的__init__函数里面设置self.nwd_loss为True.  
        比例系数调整self.iou_ratio, self.iou_ratio代表iou的占比,(1-self.iou_ratio)为代表nwd的占比.  
    在TAL标签分配中使用:
        在ultralytics/utils/tal.py中的def iou_calculation函数中进行更换即可.
    以上这两可以配合使用,也可以单独使用.

29. SlideLoss and EMASlideLoss.[Yolo-Face V2](https://github.com/Krasjet-Yu/YOLO-FaceV2/blob/master/utils/loss.py)

    在ultralytics/utils/loss.py中的class 11DetectionLoss进行设定.

30. ultralytics/cfg/models/11/yolo11-C3k2-DySnakeConv.yaml

    [DySnakeConv](https://github.com/YaoleiQi/DSCNet)与C3k2融合.
    项目视频百度云链接:20240803版本更新说明

31. ultralytics/cfg/models/11/yolo11-EfficientHead.yaml(目前还没有,v11需要重新设计一下)

    对检测头进行重设计,支持10种轻量化检测头.详细请看ultralytics/nn/extra_modules/head.py中的Detect_Efficient class.

32. ultralytics/cfg/models/11/yolo11-aux.yaml

    参考YOLOV7-Aux对YOLO11添加额外辅助训练头,在训练阶段参与训练,在最终推理阶段去掉.  
    其中辅助训练头的损失权重系数可在ultralytics/utils/loss.py中的class 11DetectionLoss中的__init__函数中的self.aux_loss_ratio设定,默认值参考yolov7为0.25.

33. ultralytics/cfg/models/11/yolo11-C3k2-DCNV2.yaml

    使用C3k2-DCNV2替换C3k2.(DCNV2为可变形卷积V2)
    项目视频百度云链接:DCNV2,DCNV3,DyHeadWithDCNV3相关讲解

34. ultralytics/cfg/models/11/yolo11-C3k2-DCNV3.yaml

    使用C3k2-DCNV3替换C3k2.([DCNV3](https://github.com/OpenGVLab/InternImage)为可变形卷积V3(CVPR2023,众多排行榜的SOTA))  
    官方中包含了一些指定版本的DCNV3 whl包,下载后直接pip install xxx即可.具体和安装DCNV3可看百度云链接中的视频.
    项目视频百度云链接:DCNV2,DCNV3,DyHeadWithDCNV3相关讲解

35. ultralytics/cfg/models/11/yolo11-dyhead-DCNV3.yaml

    使用[DCNV3](https://github.com/OpenGVLab/InternImage)替换DyHead中的DCNV2.
    项目视频百度云链接:DCNV2,DCNV3,DyHeadWithDCNV3相关讲解

36. ultralytics/cfg/models/11/yolo11-FocalModulation.yaml

    使用[Focal Modulation](https://github.com/microsoft/FocalNet)替换SPPF.

37. ultralytics/cfg/models/11/yolo11-C3k2-OREPA.yaml

    使用C3k2-OREPA替换C3k2.[Online Convolutional Re-parameterization (CVPR2022)](https://github.com/JUGGHM/OREPA_CVPR2022/tree/main)
    项目视频百度云链接:关于OREPA,REPVGGOREPA,EMSC-OREPA,EMSCP-OREPA的说明

38. ultralytics/cfg/models/11/yolo11-C3k2-REPVGGOREPA.yaml

    使用C3k2-REPVGGOREPA替换C3k2.[Online Convolutional Re-parameterization (CVPR2022)](https://github.com/JUGGHM/OREPA_CVPR2022/tree/main)
    项目视频百度云链接:关于OREPA,REPVGGOREPA,EMSC-OREPA,EMSCP-OREPA的说明

39. ultralytics/cfg/models/11/yolo11-swintransformer.yaml

    SwinTransformer-Tiny替换yolo11主干.

40. ultralytics/cfg/models/11/yolo11-repvit.yaml

    [CVPR2024 RepViT](https://github.com/THU-MIG/RepViT/tree/main)替换yolo11主干.

41. ultralytics/cfg/models/11/yolo11-fasternet-bifpn.yaml

    fasternet与bifpn的结合.  
    其中BIFPN中有三个可选参数：
    1. Fusion  
        其中BIFPN中的Fusion模块支持四种: weight, adaptive, concat, bifpn(default), SDI  
        其中weight, adaptive, concat出自[paper链接-Figure 3](https://openreview.net/pdf?id=q2ZaVU6bEsT), SDI出自[U-NetV2](https://github.com/yaoppeng/U-Net_v2)
    2. node_mode  
        其中目前(后续会更新喔)支持这些[结构](#b)
    3. head_channel  
        BIFPN中的通道数,默认设置为256.

42. ultralytics/cfg/models/11/yolo11-C3k2-DCNV2-Dynamic.yaml

    利用自研注意力机制MPCA强化DCNV2中的offset和mask.
    项目视频百度云链接:MPCA与DCNV2_Dynamic的说明

43. ultralytics/cfg/models/11/yolo11-goldyolo.yaml

    利用华为2023最新GOLD-YOLO中的Gatherand-Distribute进行改进特征融合模块
    介绍可看这期视频：https://www.bilibili.com/video/BV1Bp4y1w7MB/

44. ultralytics/cfg/models/11/yolo11-C3k2-ContextGuided.yaml

    使用[CGNet](https://github.com/wutianyiRosun/CGNet/tree/master)中的Light-weight Context Guided改进C3k2.

45. ultralytics/cfg/models/11/yolo11-ContextGuidedDown.yaml

    使用[CGNet](https://github.com/wutianyiRosun/CGNet/tree/master)中的Light-weight Context Guided DownSample进行下采样.

46. ultralytics/cfg/models/11/yolo11-C3k2-MSBlock.yaml

    使用[YOLO-MS](https://github.com/FishAndWasabi/YOLO-MS/tree/main)中的MSBlock改进C3k2.
    项目视频百度云链接:20231010版本更新说明

47. ultralytics/cfg/models/11/yolo11-C3k2-DLKA.yaml

    使用[deformableLKA](https://github.com/xmindflow/deformableLKA)改进C3k2.
    项目视频百度云链接:20231010版本更新说明

48. ultralytics/cfg/models/11/yolo11-GFPN.yaml

    使用[DAMO-YOLO](https://github.com/tinyvision/DAMO-YOLO)中的RepGFPN改进Neck.
    项目视频百度云链接:20231010版本更新说明

49. ultralytics/cfg/models/11/yolo11-SPDConv.yaml

    使用[SPDConv](https://github.com/LabSAINT/SPD-Conv/tree/main)进行下采样.
    项目视频百度云链接:20231010版本更新说明

50. ultralytics/cfg/models/11/yolo11-EfficientRepBiPAN.yaml

    使用[YOLOV6](https://github.com/meituan/YOLOv6/tree/main)中的EfficientRepBiPAN改进Neck.
    项目视频百度云链接:20231010版本更新说明

51. ultralytics/cfg/models/11/yolo11-C3k2-EMBC.yaml

    使用[Efficientnet](https://blog.csdn.net/weixin_43334693/article/details/131114618?spm=1001.2014.3001.5501)中的MBConv与EffectiveSE改进C3k2.
    项目视频百度云链接:20240920版本更新说明

52. ultralytics/cfg/models/11/yolo11-SPPF-LSKA.yaml

    使用[LSKA](https://github.com/StevenLauHKHK/Large-Separable-Kernel-Attention)注意力机制改进SPPF,增强多尺度特征提取能力.

53. ultralytics/cfg/models/11/yolo11-C3k2-DAttention.yaml

    使用[Vision Transformer with Deformable Attention(CVPR2022)](https://github.com/LeapLabTHU/DAT)改进C3k2.(需要看[常见错误和解决方案的第五点](#a))  
    使用注意点请看百度云视频.(DAttention(Vision Transformer with Deformable Attention CVPR2022)使用注意说明.)

54. ultralytics/cfg/models/11/yolo11-CSwinTransformer.yaml

    使用[CSWin-Transformer(CVPR2022)](https://github.com/microsoft/CSWin-Transformer/tree/main)替换yolo11主干.(需要看[常见错误和解决方案的第五点](#a))

55. ultralytics/cfg/models/11/yolo11-AIFI.yaml

    使用[RT-DETR](https://arxiv.org/pdf/2304.08069.pdf)中的Attention-based Intrascale Feature Interaction(AIFI)改进yolo11.
    项目视频百度云链接:20231107版本更新说明

56. ultralytics/cfg/models/11/yolo11-C3k2-Parc.yaml

    使用[ParC-Net](https://github.com/hkzhang-git/ParC-Net/tree/main)中的ParC_Operator改进C3k2.(需要看[常见错误和解决方案的第五点](#a))  
    使用注意点请看百度云视频.(20231031更新说明)    

57. ultralytics/cfg/models/11/yolo11-C3k2-DWR.yaml

    使用[DWRSeg](https://arxiv.org/abs/2212.01173)中的Dilation-wise Residual(DWR)模块,加强从网络高层的可扩展感受野中提取特征.
    项目视频百度云链接:20231107版本更新说明

58. ultralytics/cfg/models/11/yolo11-C3k2-RFAConv.yaml

    使用[RFAConv](https://github.com/Liuchen1997/RFAConv/tree/main)中的RFAConv改进yolo11.

59. ultralytics/cfg/models/11/yolo11-C3k2-RFCBAMConv.yaml

    使用[RFAConv](https://github.com/Liuchen1997/RFAConv/tree/main)中的RFCBAMConv改进yolo11.

60. ultralytics/cfg/models/11/yolo11-C3k2-RFCAConv.yaml

    使用[RFAConv](https://github.com/Liuchen1997/RFAConv/tree/main)中的RFCAConv改进yolo11.

61. ultralytics/cfg/models/11/yolo11-HGNetV2.yaml

    使用HGNetV2作为YOLO11的backbone.

62. ultralytics/cfg/models/11/yolo11-GhostHGNetV2.yaml

    使用Ghost_HGNetV2作为YOLO11的backbone.
    项目视频百度云链接:GhostHGNetV2、RepHGNetV2改进说明

63. ultralytics/cfg/models/11/yolo11-RepHGNetV2.yaml

    使用Rep_HGNetV2作为YOLO11的backbone.
    项目视频百度云链接:GhostHGNetV2、RepHGNetV2改进说明

64. ultralytics/cfg/models/11/yolo11-seg-EfficientHead.yaml(实例分割)(目前还没有,v11需要重新设计一下)

    对检测头进行重设计,支持10种轻量化检测头.详细请看ultralytics/nn/extra_modules/head.py中的Detect_Efficient class.[YOLO11改进-带你分析11的检测头并重设计10种结构轻量化检测头](https://www.bilibili.com/video/BV1cu411K7FE/)  

65. ultralytics/cfg/models/11/yolo11-C3k2-FocusedLinearAttention.yaml

    使用[FLatten Transformer(ICCV2023)](https://github.com/LeapLabTHU/FLatten-Transformer)中的FocusedLinearAttention改进C3k2.(需要看[常见错误和解决方案的第五点](#a))    
    使用注意点请看百度云视频.(20231114版本更新说明.)

66. IoU,GIoU,DIoU,CIoU,EIoU,SIoU更换方法.

    请看LOSS改进系列.md

67. Inner-IoU,Inner-GIoU,Inner-DIoU,Inner-CIoU,Inner-EIoU,Inner-SIoU更换方法.

    请看LOSS改进系列.md

68. Inner-MPDIoU更换方法.

    请看LOSS改进系列.md

69. ultralytics/cfg/models/11/yolo11-C3k2-MLCA.yaml

    使用[Mixed Local Channel Attention 2023](https://github.com/wandahangFY/MLCA/tree/master)改进C3k2.(用法请看百度云视频-20231129版本更新说明)

70. ultralytics/cfg/models/11/yolo11-C3k2-AKConv.yaml

    使用[AKConv 2023](https://github.com/CV-ZhangXin/AKConv)改进C3k2.(用法请看百度云视频-20231129版本更新说明)

71. ultralytics/cfg/models/11/yolo11-unireplknet.yaml

    使用[UniRepLKNet](https://github.com/AILab-CVC/UniRepLKNet/tree/main)替换yolo11主干.
    项目视频百度云链接:20231207版本更新说明

72. ultralytics/cfg/models/11/yolo11-C3k2-UniRepLKNetBlock.yaml

    使用[UniRepLKNet](https://github.com/AILab-CVC/UniRepLKNet/tree/main)中的UniRepLKNetBlock改进C3k2.
    项目视频百度云链接:20231207版本更新说明

73. ultralytics/cfg/models/11/yolo11-C3k2-DRB.yaml

    使用[UniRepLKNet](https://github.com/AILab-CVC/UniRepLKNet/tree/main)中的DilatedReparamBlock改进C3k2.
    项目视频百度云链接:20231207版本更新说明

74. ultralytics/cfg/models/11/yolo11-C3k2-DWR-DRB.yaml

    使用[UniRepLKNet](https://github.com/AILab-CVC/UniRepLKNet/tree/main)中的DilatedReparamBlock对[DWRSeg](https://arxiv.org/abs/2212.01173)中的Dilation-wise Residual(DWR)的模块进行二次创新后改进C3k2.
    项目视频百度云链接:20231207版本更新说明

75. ultralytics/cfg/models/11/yolo11-ASF.yaml

    使用[ASF-YOLO](https://github.com/mkang315/ASF-YOLO)中的Attentional Scale Sequence Fusion改进yolo11.
    项目视频百度云链接:20231217版本更新说明

76. ultralytics/cfg/models/11/yolo11-ASF-P2.yaml

    在ultralytics/cfg/models/11/yolo11-ASF.yaml的基础上进行二次创新，引入P2检测层并对网络结构进行优化.
    项目视频百度云链接:20231217版本更新说明

77. ultralytics/cfg/models/11/yolo11-CSP-EDLAN.yaml

    使用[DualConv](https://github.com/ChipsGuardian/DualConv)打造CSP Efficient Dual Layer Aggregation Networks改进yolo11.
    项目视频百度云链接:20231217版本更新说明

78. ultralytics/cfg/models/11/yolo11-TransNeXt.yaml

    使用[TransNeXt](https://github.com/DaiShiResearch/TransNeXt)改进yolo11的backbone.(需要看[常见错误和解决方案的第五点](#a))   

79. ultralytics/cfg/models/11/yolo11-AggregatedAttention.yaml

    使用[TransNeXt](https://github.com/DaiShiResearch/TransNeXt)中的聚合感知注意力改进yolo11的backbone.(需要看[常见错误和解决方案的第五点](#a))   
    项目视频百度云链接:20231227版本更新说明

80. ultralytics/cfg/models/11/yolo11-C3k2-AggregatedAtt.yaml

    使用[TransNeXt](https://github.com/DaiShiResearch/TransNeXt)中的聚合感知注意力改进C3k2.(需要看[常见错误和解决方案的第五点](#a))   
    项目视频百度云链接:20231227版本更新说明

81. ultralytics/cfg/models/11/yolo11-bifpn-SDI.yaml

    使用[U-NetV2](https://github.com/yaoppeng/U-Net_v2)中的 Semantics and Detail Infusion Module对BIFPN进行二次创新.
    项目视频百度云链接:20231227版本更新说明

82. ultralytics/cfg/models/11/yolo11-SDI.yaml

    使用[U-NetV2](https://github.com/yaoppeng/U-Net_v2)中的 Semantics and Detail Infusion Module对yolo11中的feature fusion部分进行重设计.
    项目视频百度云链接:20231227版本更新说明

83. Shape-IoU,Inner-Shape-IoU更换方法.

    请看LOSS改进系列.md

84. FocalLoss,VarifocalLoss,QualityfocalLoss更换方法.

    请看LOSS改进系列.md

85. Wise-IoU(v1,v2,v3)系列(IoU,WIoU,EIoU,GIoU,DIoU,CIoU,SIoU,MPDIoU,ShapeIoU)更换方法.

    请看LOSS改进系列.md

86. Inner-Wise-IoU(v1,v2,v3)系列(IoU,WIoU,EIoU,GIoU,DIoU,CIoU,SIoU,MPDIoU,ShapeIoU)更换方法.

    请看LOSS改进系列.md

87. ultralytics/cfg/models/11/yolo11-goldyolo-asf.yaml

    利用华为2023最新GOLD-YOLO中的Gatherand-Distribute与[ASF-YOLO](https://github.com/mkang315/ASF-YOLO)中的Attentional Scale Sequence Fusion进行二次创新改进yolo11的neck.
    项目视频百度云链接:20240116版本更新说明

88. ultralytics/cfg/models/11/yolo11-C2f-DCNV4.yaml

    使用[DCNV4](https://github.com/OpenGVLab/DCNv4)改进C2f.(请关闭AMP进行训练,使用教程请看20240116版本更新说明)

89. ultralytics/cfg/models/11/yolo11-dyhead-DCNV4.yaml

    使用[DCNV4](https://github.com/OpenGVLab/DCNv4)对DyHead进行二次创新.(请关闭AMP进行训练,使用教程请看20240116版本更新说明)

90. ultralytics/cfg/models/11/yolo11-HSFPN.yaml

    使用[MFDS-DETR](https://github.com/JustlfC03/MFDS-DETR)中的HS-FPN改进yolo11的neck.
    项目视频百度云链接:20240122版本更新说明

91. ultralytics/cfg/models/11/yolo11-HSPAN.yaml

    对[MFDS-DETR](https://github.com/JustlfC03/MFDS-DETR)中的HS-FPN进行二次创新后得到HSPAN改进yolo11的neck.
    项目视频百度云链接:20240122版本更新说明

92. soft-nms(IoU,GIoU,DIoU,CIoU,EIoU,SIoU,ShapeIoU)

    soft-nms替换nms.(建议:仅在val.py时候使用,具体替换请看20240122版本更新说明)

93. ultralytics/cfg/models/11/yolo11-dysample.yaml

    使用[ICCV2023 DySample](https://arxiv.org/abs/2308.15085)改进yolo11-neck中的上采样.
    项目视频百度云链接:20240122版本更新说明

94. ultralytics/cfg/models/11/yolo11-CARAFE.yaml

    使用[ICCV2019 CARAFE](https://arxiv.org/abs/1905.02188)改进yolo11-neck中的上采样.
    项目视频百度云链接:20240122版本更新说明

95. ultralytics/cfg/models/11/yolo11-HWD.yaml

    使用[Haar wavelet downsampling](https://www.sciencedirect.com/science/article/abs/pii/S0031320323005174)改进yolo11的下采样.(请关闭AMP情况下使用)
    项目视频百度云链接:20240122版本更新说明

96. Focaler-IoU系列(IoU,GIoU,DIoU,CIoU,EIoU,SIoU,WIoU,MPDIoU,ShapeIoU)

    请看LOSS改进系列.md

97. ultralytics/cfg/models/11/yolo11-GDFPN.yaml

    使用[DAMO-YOLO](https://github.com/tinyvision/DAMO-YOLO)中的RepGFPN与[ICCV2023 DySample](https://arxiv.org/abs/2308.15085)进行二次创新改进Neck.
    项目视频百度云链接:20240203版本更新说明

98. ultralytics/cfg/models/11/yolo11-HSPAN-DySample.yaml

    对[MFDS-DETR](https://github.com/JustlfC03/MFDS-DETR)中的HS-FPN进行二次创新后得到HSPAN再进行创新,使用[ICCV2023 DySample](https://arxiv.org/abs/2308.15085)改进其上采样模块.
    项目视频百度云链接:20240203版本更新说明

99. ultralytics/cfg/models/11/yolo11-ASF-DySample.yaml

    使用[ASF-YOLO](https://github.com/mkang315/ASF-YOLO)中的Attentional Scale Sequence Fusion与[ICCV2023 DySample](https://arxiv.org/abs/2308.15085)组合得到Dynamic Sample Attentional Scale Sequence Fusion.
    项目视频百度云链接:20240203版本更新说明

100. ultralytics/cfg/models/11/yolo11-SEAMHead.yaml

    使用[YOLO-Face V2](https://arxiv.org/pdf/2208.02019v2.pdf)中的遮挡感知注意力改进Head,使其有效地处理遮挡场景.
    项目视频百度云链接:20240920版本更新说明

101. ultralytics/cfg/models/11/yolo11-MultiSEAMHead.yaml

    使用[YOLO-Face V2](https://arxiv.org/pdf/2208.02019v2.pdf)中的遮挡感知注意力改进Head,使其有效地处理遮挡场景.
    项目视频百度云链接:20240920版本更新说明

# 常见错误和解决方案(如果是跑自带的一些配置文件报错可以先看看对应的配置文件是否有提示需要修改内容)
1. RuntimeError: xxxxxxxxxxx does not have a deterministic implementation, but you set 'torch.use_deterministic_algorithms(True)'.....

    解决方案：在ultralytics/utils/torch_utils.py中init_seeds函数中把torch.use_deterministic_algorithms里面的True改为False

2. ModuleNotFoundError：No module named xxx

    解决方案：缺少对应的包，先把YOLO11环境配置的安装命令进行安装一下，如果还是缺少显示缺少包，安装对应的包即可(xxx就是对应的包).

3. OMP: Error #15: Initializing libiomp5md.dll, but found libiomp5md.dll already initialized.  

    解决方案：https://zhuanlan.zhihu.com/p/599835290

4. 训练过程中loss出现nan.

    可以尝试关闭AMP混合精度训练.(train.py中加amp=False)

<a id="a"></a>

5. 固定640x640尺寸的解决方案.

    运行train.py中的时候需要在ultralytics/models/yolo/detect/train.py的DetectionTrainer class中的build_dataset函数中的rect=mode == 'val'改为rect=False.其他模型可以修改回去.  
    运行val.py的时候,把val.py的rect=False注释取消即可.其他模型可以修改回去.  
    运行detect.py中的时候需要在ultralytics/engine/predictor.py找到函数def pre_transform(self, im),在LetterBox中的auto改为False,其他模型可以修改回去.  

6. 多卡训练问题.[参考链接](https://docs.ultralytics.com/yolov5/tutorials/multi_gpu_training/#multi-gpu-dataparallel-mode-not-recommended:~:text=just%201%20GPU.-,Multi%2DGPU%20DistributedDataParallel%20Mode%20(%E2%9C%85%20recommended),-You%20will%20have)

    python -m torch.distributed.run --nproc_per_node 2 train.py

7. 指定显卡训练.

    参考链接:https://blog.csdn.net/m0_55097528/article/details/130323125
    在train.py中不需要指定device参数，使用命令行的运行方式去跑，例如我需要在显卡1上训练，命令是：CUDA_VISIBLE_DEVICES=1 python train.py

8. ValueError: Expected more than 1 value per channel when training, got input size torch.Size...

    请注意看控制台输出信息，如果是训练阶段的最后一个batch出现这个报错，证明最后一个batch的大小为1，可以去掉训练集的一张图或者加一张图避免出现这个情况，又或者更改batch。
    同样地，如果在训练时候的验证阶段出现这个情况，跟上述处理一样，可以去掉验证集的一张图或者加一张图避免出现这个情况，又或者更改batch。

9. AttributeError: Can't pickle local object 'EMASlideLoss.__init__.<locals>.<lambda>'

    可以在ultralytics/utils/loss.py中添加import dill as pickle,然后装一下dill这个包.  
    pip install dill -i https://pypi.tuna.tsinghua.edu.cn/simple

10. RuntimeError: Dataset 'xxxxx' error ❌

    将data.yaml中的路径都改为绝对路径.

11. WARNING  NMS time limit 2.100s exceeded

    在ultralytics/utils/ops.py中non_max_suppression函数里面找到这个语句：
        time_limit = 2.0 + max_time_img * bs  # seconds to quit after
    前面的2.0自己改大点即可，大到不会出现这个NMS time limit即可.

12. OSError: [WinError 1455] 页面文件太小，无法完成操作。

    此问题常见于windows训练.一般情况下有两种解决方案:
    1. 把workers设置小点直接不会报错.最小为0
    2. 扩大虚拟内存(可百度).